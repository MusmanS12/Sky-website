from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('health_check/', include('Health_check.urls')),
    path('', RedirectView.as_view(url='/health_check/login/', permanent=False)),
]
