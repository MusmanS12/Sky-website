from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from .models import UserProfile, HealthCard

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=False)
    last_name = forms.CharField(max_length=30, required=False)
    contact_number = forms.CharField(max_length=20, required=False)
    date_of_birth = forms.DateField(required=False, widget=forms.DateInput(attrs={'type': 'date'}))
    ROLE_CHOICES = [
        ('engineer', 'Engineer'),
        ('team_leader', 'Team Leader'),
        ('department_leader', 'Department Leader'),
        ('senior_manager', 'Senior Manager'),
        ('admin', 'Admin')
    ]
    role = forms.ChoiceField(choices=ROLE_CHOICES, required=True)
    
    address_line1 = forms.CharField(max_length=255, required=False, label='Address Line 1')
    address_line2 = forms.CharField(max_length=255, required=False, label='Address Line 2')
    address_line3 = forms.CharField(max_length=255, required=False, label='Address Line 3')
    city = forms.CharField(max_length=100, required=False, label='Town/City')
    postcode = forms.CharField(max_length=20, required=False, label='Postcode')
    country = forms.CharField(max_length=100, required=False, label='Country')
    
    class Meta:
        model = User
        fields = [
            'username', 'email', 'first_name', 'last_name',
            'password1', 'password2',
            'contact_number', 'date_of_birth', 'role',
            'address_line1', 'address_line2', 'address_line3',
            'city', 'postcode', 'country'
        ]
        
    def save(self, commit=True):
        user = super().save(commit=commit)
        profile, created = UserProfile.objects.get_or_create(user=user)
        profile.user_contact_number = self.cleaned_data.get('contact_number')
        profile.user_DOB = self.cleaned_data.get('date_of_birth')
        profile.user_Role = self.cleaned_data.get('role')
        profile.address_line1 = self.cleaned_data.get('address_line1')
        profile.address_line2 = self.cleaned_data.get('address_line2')
        profile.address_line3 = self.cleaned_data.get('address_line3')
        profile.city = self.cleaned_data.get('city')
        profile.postcode = self.cleaned_data.get('postcode')
        profile.country = self.cleaned_data.get('country')
        if commit:
            profile.save()
        return user

class UserLoginForm(AuthenticationForm):
    ROLE_CHOICES = [
        ('engineer', 'Engineer'),
        ('team_leader', 'Team Leader'),
        ('department_leader', 'Department Leader'),
        ('senior_manager', 'Senior Manager'),
        ('admin', 'Admin')
    ]
    role = forms.ChoiceField(choices=ROLE_CHOICES, required=True, label="Login As")
    username = forms.CharField(max_length=254, widget=forms.TextInput(attrs={'autofocus': True}))
    password = forms.CharField(label="Password", strip=False, widget=forms.PasswordInput)

    class Meta:
        medel = User
        fields = ['role', 'username', 'password']

class VoteForm(forms.Form):
    def __init__(self, *args, **kwargs):
        cards = kwargs.pop('cards')
        super().__init__(*args, **kwargs)
        for card in cards:
            field_name = f'vote_{card.pk}'
            comment_name = f'comment_{card.pk}'
            # choice field
            self.fields[field_name] = forms.ChoiceField(
                label = card.card_Title,
                choices=(
                    ('green', 'Green'),
                    ('amber', 'Amber'),
                    ('red', 'Red')
                ),
                widget=forms.RadioSelect,
                required=False
            )
            # comment
            self.fields[comment_name] = forms.CharField(
                label='Comments',
                widget=forms.Textarea(attrs={'rows': 2}),
                required=False
            )

class ProfileForm(forms.ModelForm):
    full_name = forms.CharField(label = "Full Name", max_length=150)
    email = forms.EmailField(label = "Email Address")

    class Meta:
        model = UserProfile
        fields = ['user_contact_number', 'user_DOB', ]
        widgets = {
            'user_DOB': forms.DateInput(attrs={'type': 'date'})
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        self.fields['full_name'].initial = f"{user.first_name} {user.last_name}".strip()
        self.fields['email'].initial = user.email
    
    def save(self, commit=True):
        profile = super().save(commit=False)
        name = self.cleaned_data['full_name'].split(None, 1)
        first = name[0]
        last = name[1] if len(name) > 1 else ''
        user = profile.user
        user.first_name = first
        user.last_name = last
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
            profile.save()
        return profile