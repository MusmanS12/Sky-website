import json
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.template import loader
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseForbidden
from django.utils import timezone
from .models import UserProfile, Department, HealthCard, Vote, TeamSummary, Session, Team
from .forms import UserLoginForm, UserRegisterForm, VoteForm, ProfileForm


# Create your views here.
def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserRegisterForm()
    template = loader.get_template('register.html')
    context = {
        'form': form,
    }
    return HttpResponse(template.render(context, request))

def login_view(request):
    if request.method == 'POST':
        form = UserLoginForm(request, data=request.POST)
        if form.is_valid():
            role_submitted = form.cleaned_data['role']
            user = form.get_user()
            role = user.userprofile.user_Role
            if role == role_submitted:
                login(request, user)
                return redirect('dashboard')
            else:
                form.add_error('role', 'That role does not match your account')
    else:
        form = UserLoginForm()
    template = loader.get_template('Login.html')
    context = {
        'form': form,
    }
    return HttpResponse(template.render(context, request))

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=request.user.userprofile, user = request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Your profile has been updated.")
            return redirect('profile')
    else:
        form = ProfileForm(instance=request.user.userprofile, user = request.user)
    context = {
        'form': form,
    }
    template = loader.get_template('profile.html')

    return HttpResponse(template.render(context, request))

@login_required
def dashboard(request):
    role = request.user.userprofile.user_Role
    if role == 'engineer':
        tpl = 'engineer_dashboard.html'
    elif role == 'team_leader':
        tpl = 'Team_leader_dashboard.html'
    elif role == 'admin':
        tpl = 'admin_dashboard.html'
    elif role == 'senior_manager':
        tpl = 'Senior_manager_dashboard.html'
    else:
        tpl = 'department_dashboard.html'
    return render(request, tpl, {})

@login_required
def manage_cards(request):
    role = request.user.userprofile.user_Role
    if role == 'team_leader':
        tpl = 'manage_cards.html'
    elif role == 'department_leader':
        tpl = 'manage_cards.html'
    elif role == 'admin':
        tpl = 'manage_cards.html'
    else:
        return HttpResponseForbidden("You are not authorized to view this page.")

    template = loader.get_template(tpl)

    if request.method == 'POST':
        title = request.POST.get('card_title')
        descr = request.POST.get('card_description')
        if title and descr:
            HealthCard.objects.create(
                card_Title=title,
                card_Description=descr,
                card_Creation=timezone.now(),
                card_Priority='Normal',
                card_Status='Open'
            )
            return redirect('manage_cards')
    cards = HealthCard.objects.all()
    context = {
        'cards': cards,
    }
    return HttpResponse(template.render(context, request))

@login_required
def manage_teams(request):
    role = request.user.userprofile.user_Role
    if role == 'team_leader':
        template = loader.get_template('manage_teams.html')
    elif role == 'department_leader':
        template = loader.get_template('manage_teams.html')
    elif role == 'senior_manager':
        template = loader.get_template('manage_teams.html')
    elif role == 'admin':
        template = loader.get_template('manage_teams.html')
    else:
        return HttpResponseForbidden("You are not authorized to view this page.")

    if request.method == 'POST':
        name = request.POST.get('team_name', '').strip()
        members_raw = request.POST.get('members', '').strip()
        if name:
            size = len([u.strip() for u in members_raw.split(',') if u.strip()])
            dept = Department.objects.first()
            Team.objects.create(
                team_Name = name,
                team_Size = size,
                team_Description = '',
                team_Leader = request.user,
                department = dept
            )
            return redirect('manage_team')
    
    teams = Team.objects.all().order_by('team_ID')
    context = {
        'teams': teams,
    }
    return HttpResponse(template.render(context, request))

@login_required
def manage_departments(request):
    role = request.user.userprofile.user_Role
    if role == 'department_leader':
        template = loader.get_template('manage_department.html')
    elif role == 'senior_manager':
        template = loader.get_template('manage_department.html')
    elif role == 'admin':
        template = loader.get_template('manage_department.html')
    else:
        return HttpResponseForbidden("You are not authorized to view this page.")
    
    if request.method == 'POST':
        name = request.POST.get('department_name', '').strip()
        if name:
            Department.objects.create(
                department_Name=name
            )
            return redirect('manage_department')
    departments = Department.objects.all().order_by('department_ID')
    context = {
        'departments': departments,
    } 
    return HttpResponse(template.render(context, request))

@login_required
def manage_sessions(request):
    role = request.user.userprofile.user_Role
    if role == 'admin':
        template = loader.get_template('manage_sessions.html')
    else:
        return HttpResponseForbidden("You are not authorized to view this page.")

    if request.method == 'POST':
        name = request.POST.get('session_name', '').strip()
        date = request.POST.get('session_date')
        if name and date:
            Session.objects.create(
                session_Name = name,
                session_Start_Time = date,
                session_End_Time = date,
                session_Type = 'Default',
                session_Status = 'Open'
            )
            return redirect('manage_sessions')
    
    sessions = Session.objects.all().order_by('session_ID')

    context = {
        'sessions': sessions,
    }
    
    return HttpResponse(template.render(context,request))

@login_required
def manage_users(request):
    role = request.user.userprofile.user_Role
    if role == 'admin':
        template = loader.get_template('manage_users.html')
    else:
        return HttpResponseForbidden("You are not authorized to view this page.")
    
    if request.method == 'POST':
        full_name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        role_sel = request.POST.get('role')
        password = request.POST.get('password')

        if full_name and email and password and role_sel:
            parts = full_name.split(None, 1)
            first = parts[0]
            last = parts[1] if len(parts) > 1 else ''

            # Create user
            user = User.objects.create_user(
                username = email,
                email = email,
                password = password,
                first_name = first,
                last_name = last,
            )

            # attach profile
            UserProfile.objects.create(
                user = user,
                user_contact_number = '',
                user_DOB = None,
                user_Role = role_sel,
                address_line1 = '',
                address_line2 = '',
                address_line3 = '',
                city = '',
                postcode = '',
                country = ''
            )
            return redirect('manage_users')
    users = User.objects.select_related('userprofile').all().order_by('id')
    context = {
        'users': users,
    }
    return HttpResponse(template.render(context,request))

@login_required
def voting(request):
    user = request.user
    role = request.user.userprofile.user_Role
    if role == 'engineer':
        tpl = 'Engineer_voting_page.html'
    elif role == 'team_leader':
        tpl = 'Team_leader_voting_page.html'
    else:
        return HttpResponse("Unauthorized", status=403)
    
    cards = HealthCard.objects.all()

    if request.method == 'POST':
        form = VoteForm(request.POST, cards=cards)
        if form.is_valid():
            session = user.userprofile.session_set.first()
            team = user.userprofile.team_set.first()
        
            for card in cards:
                vote_val = form.cleaned_data.get(f'vote_{card.pk}')
                comment_val = form.cleaned_data.get(f'comment_{card.pk}')
                if vote_val:
                    Vote.objects.create(
                        voteStatus=vote_val,
                        comment=comment_val or '',
                        User=user,
                        team=team,
                        session=session,
                        card=card,
                    )
            green_count = Vote.objects.filter(
                User=user, team=team, session=session, voteStatus=Vote.GREEN
            ).count()

            ts, _ = TeamSummary.objects.get_or_create(
                team=team, session=session,
                defaults={
                    'summary_Green_Vote': 0,
                    'summary_Amber_Vote': 0,
                    'summary_Red_Vote': 0,
                }
            )
            ts.summary_Green_Vote = green_count
            ts.save()

            return redirect('dashboard')
    else:
        form = VoteForm(cards=cards)
    
    template = loader.get_template(tpl)
    context={
        'form': form,
        'cards': cards,
    }
    return HttpResponse(template.render(context, request))

@login_required
def visualisation(request):
    cards = HealthCard.objects.all().order_by('card_Title')
    labels = [c.card_Title for c in cards]
    green_data = []
    amber_data = []
    red_data = []
    for card in cards:
        green_data.append(
            Vote.objects.filter(card=card, voteStatus='green').count()
        )
        amber_data.append(
            Vote.objects.filter(card=card, voteStatus='amber').count()
        )
        red_data.append(
            Vote.objects.filter(card=card, voteStatus='red').count()
        )
        context = {
            'labels_json': json.dumps(labels),
            'green_json': json.dumps(green_data),
            'amber_json': json.dumps(amber_data),
            'red_json': json.dumps(red_data),
        }
    template = loader.get_template('visualisation.html')
    return HttpResponse(template.render(context, request))