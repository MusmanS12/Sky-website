from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class AdminModel(models.Model):
    admin_ID = models.AutoField(primary_key=True, db_column='admin_ID')
    admin_permission = models.TextField(db_column='admin_permission')
    User = models.OneToOneField(User, on_delete=models.CASCADE, db_column='user_ID')
    summary_ID = models.IntegerField(db_column='summary_ID')

    class Meta:
        db_table = 'Admins'

class Department(models.Model):
    department_ID = models.AutoField(primary_key=True, db_column='department_ID')
    department_Name = models.CharField(max_length=255, db_column='department_name')

    class Meta:
        db_table = 'Departments'

class DepartmentSummary(models.Model):
    dept_summary_ID = models.AutoField(primary_key=True, db_column='dept_summary_ID')
    overall_Green_Vote = models.IntegerField(db_column='overall_Green_Vote')
    overall_Amber_Vote = models.IntegerField(db_column='overall_Amber_Vote')
    overall_Red_Vote = models.IntegerField(db_column='overall_Red_Vote')
    session = models.ForeignKey('Session', on_delete=models.CASCADE, db_column='session_ID')
    department = models.ForeignKey(Department, on_delete=models.CASCADE, db_column='department_ID')

    class Meta:
        db_table = 'Department Summary'

class HealthCard(models.Model):
    card_ID = models.AutoField(primary_key=True, db_column='card_ID')
    card_Title = models.CharField(max_length=255, db_column='card_Title')
    card_Description = models.TextField(db_column='card_Description')
    card_Creation = models.DateTimeField(db_column='card_Creation')
    card_Priority = models.CharField(max_length=50, db_column='card_Priority')
    card_Status = models.CharField(max_length=50, db_column='card_Status')

    class Meta:
        db_table = 'HealthCards'

class Session(models.Model):
    session_ID = models.AutoField(primary_key=True, db_column='session_ID')
    session_Name = models.TextField(db_column='session_Name')
    session_Start_Time = models.TimeField(db_column='session_Start_Time')
    session_End_Time = models.TimeField(db_column='session_End_Time')
    session_Type = models.CharField(max_length=100, db_column='session_Type')
    session_Status = models.CharField(max_length=50, db_column='session_Status')

    class Meta:
        db_table = 'Sessions'

class Team(models.Model):
    team_ID = models.AutoField(primary_key=True, db_column='team_ID')
    team_Name = models.CharField(max_length=255, db_column='team_Name')
    team_Size = models.IntegerField(db_column='team_Size')
    team_Description = models.TextField(db_column='team_Description')
    team_Leader = models.ForeignKey(User, on_delete=models.CASCADE, db_column='team_Leader_ID')
    department = models.ForeignKey(Department, on_delete=models.CASCADE, db_column='department_ID')

    class Meta:
        db_table = 'Teams'  
    
class TeamSummary(models.Model):
    summary_ID = models.AutoField(primary_key=True, db_column='summary_ID')
    summary_Green_Vote = models.IntegerField(db_column='summary_Green_Vote')
    summary_Amber_Vote = models.IntegerField(db_column='summary_Amber_Vote')
    summary_Red_Vote = models.IntegerField(db_column='summary_Red_Vote')
    session = models.ForeignKey(Session, on_delete=models.CASCADE, db_column='session_ID')
    team = models.ForeignKey(Team, on_delete=models.CASCADE, db_column='team_ID')
    card = models.ForeignKey(HealthCard, on_delete=models.CASCADE, db_column='card_ID')

    class Meta:
        db_table = 'Teams Summary'

class Vote(models.Model):
    GREEN = 'green'
    AMBER = 'amber'
    RED = 'red'
    VOTE_CHOICES = [
        (GREEN, 'Green'),
        (AMBER, 'Amber'),
        (RED, 'Red'),
    ]
    vote_ID = models.AutoField(primary_key=True, db_column='vote_ID')
    voteStatus = models.CharField(max_length=50, db_column='voteStatus') 
    comment = models.TextField(db_column='comment', blank=True)   
    vote_Process = models.IntegerField(db_column='vote_Process')
    User = models.ForeignKey(User, on_delete=models.CASCADE, db_column='user_ID')
    team = models.ForeignKey(Team, on_delete=models.CASCADE, db_column='team_ID')
    session = models.ForeignKey(Session, on_delete=models.CASCADE, db_column='session_ID')
    card = models.ForeignKey(HealthCard, on_delete=models.CASCADE, db_column='card_ID')

    class Meta:
        db_table = 'Votes'

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, db_column='user_ID')
    user_contact_number = models.CharField(max_length=20, db_column='contact_number')
    user_DOB = models.DateField(db_column='DOB', blank=True, null=True)
    user_Role = models.CharField(max_length=20, db_column='user_Role')
    address_line1 = models.CharField(max_length=255, blank=True)
    address_line2 = models.CharField(max_length=255, blank=True)
    address_line3 = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=100, blank=True)
    postcode = models.CharField(max_length=20, blank=True)
    country = models.CharField(max_length=100, blank=True)

    class Meta:
        db_table = 'UserProfiles'

    def __str__(self):
        return self.user.username
