from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('forgot_password/', auth_views.PasswordResetView.as_view(template_name='forgot_password.html', success_url='forgot_password_sent/'), name='forgot_password'),
    path('forgot_password_sent/', auth_views.PasswordResetDoneView.as_view(template_name='forgot_password_sent.html'), name='password_reset_done'),
    path('change_password/', auth_views.PasswordChangeView.as_view(template_name='change_password.html', success_url='/password-change/done/'), name='change_password'),
    path('password-change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='change_password_done.html'), name='password_change_done'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile, name='profile'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('manage-cards/', views.manage_cards, name='manage_cards'),
    path('manage-team/', views.manage_teams, name='manage_teams'),
    path('manage-department/', views.manage_departments, name='manage_departments'),
    path('manage-sessions/', views.manage_sessions, name='manage_sessions'),
    path('manage-users/', views.manage_users, name='manage_users'),
    path('voting/', views.voting, name='voting'),
    path('visualisation/', views.visualisation, name='visualisation'),
]
