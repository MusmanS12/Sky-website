from django.contrib import admin
from .models import AdminModel, Department, DepartmentSummary, HealthCard, Session, Team, TeamSummary, Vote, UserProfile

# Register your models here.
@admin.register(AdminModel)
class AdminModelAdmin(admin.ModelAdmin):
    list_display = ('admin_ID', 'admin_permission', 'summary_ID')
    list_filter = ('admin_permission',)
    search_fields = ('user_first_Name', 'user_last_name', 'admin_permission')

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('department_ID', 'department_Name')
    search_fields = ('department_Name',)

@admin.register(DepartmentSummary)
class DepartmentSummaryAdmin(admin.ModelAdmin):
    list_display = ('dept_summary_ID', 'overall_Green_Vote', 'overall_Amber_Vote', 'overall_Red_Vote', 'session', 'department')
    list_filter = ('overall_Green_Vote', 'overall_Amber_Vote', 'overall_Red_Vote')
    search_fields = ('session__session_Name', 'department__department_Name')

@admin.register(HealthCard)
class HealthCardAdmin(admin.ModelAdmin):
    list_display = ('card_ID', 'card_Title', 'card_Description', 'card_Creation', 'card_Priority', 'card_Status')
    list_filter = ('card_Priority', 'card_Status')
    search_fields = ('card_Title',)

@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ('session_ID', 'session_Name', 'session_Start_Time', 'session_End_Time', 'session_Type', 'session_Status')
    list_filter = ('session_Type', 'session_Status')
    search_fields = ('session_Name', 'card_Title')

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('team_ID', 'team_Name', 'team_Size', 'team_Description', 'team_Leader', 'department')
    list_filter = ('team_Size', 'department')
    search_fields = ('team_Name', 'team_Leader__username', 'department__department_Name')

@admin.register(TeamSummary)
class TeamSummaryAdmin(admin.ModelAdmin):
    list_display = ('summary_ID', 'summary_Green_Vote', 'summary_Amber_Vote', 'summary_Red_Vote', 'session', 'team')
    list_filter = ('summary_Green_Vote', 'summary_Amber_Vote', 'summary_Red_Vote')
    search_fields = ('session__session_Name', 'team__team_Name')

@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('vote_ID', 'voteStatus', 'vote_Process', 'User', 'session', 'team', 'card')
    list_filter = ('voteStatus', 'vote_Process')
    search_fields = ('session__session_Name', 'team__team_Name', 'card__card_Title', 'User__username')

@admin.register(UserProfile)
class UserAdmin(admin.ModelAdmin):
    list_display = ('user', 'user_contact_number', 'user_DOB', 'user_Role')
    search_fields = ('user_Role', 'user__username', 'user_contact_number')
    list_filter = ('user__username', 'user_contact_number')
